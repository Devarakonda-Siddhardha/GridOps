===================================================================
⚡ PANTHEON'S WRATH: RECLAMATION OF HELLAS (v2.0.0 CAMPAIGN EDITION) ⚡
===================================================================

A Greek Mythos 3D Action RPG & Army Campaign built with Godot 4.7
and Blender 4.2 LTS with dynamic ElevenLabs AI voice acting.

--- THE STORY: RECLAIMING THE GREEK EMPIRE ---
You begin as a lone Spartan warrior after the Roman legions marched
across Hellas, capturing its warriors and burning its shrines.
By invoking the wrath of the Olympian Gods, you must storm Roman
encampments across the Great Valley of Arcadia, liberate captured
Spartan hoplites, forge a mighty Greek Phalanx, and lead your army
in a full-scale siege against Castrum Roma to slay General Marcus
and restore the Greek Empire!

--- CAMPAIGN CHAPTERS ---
• CHAPTER I: THE SANCTUARY OF OLYMPUS
  Defend the sacred summit alone. Pray at the 4 Olympian Altars
  to unlock Zeus's Lightning, Poseidon's Tides, Hades's Soul Leech,
  and Ares's Berserk Fury. Crush the Roman vanguard.

• CHAPTER II: THE VALLEY OF ARCADIA
  A vast 200m x 200m open landscape overrun by Roman cohorts.
  Storm 3 fortified Roman outposts, slay the Centurions, and break
  open the wooden cages to liberate 12 Greek Hoplite soldiers who
  join your army squad.

• CHAPTER III: THE SIEGE OF CASTRUM ROMA
  Lead your Greek Phalanx in a massive fortress assault.
  Breach the fortified Castrum gate, shatter the Roman cohort, and
  defeat Legatus General Marcus Aurelius in an epic 2-phase boss fight!

--- CONTROLS ---
• W, A, S, D / Arrow Keys : Move Warrior
• Left Mouse / Spacebar   : 3-Hit Sword Attack Combo (Damages enemies & cages/gates)
• Shift                   : Tactical Dodge Roll (Invulnerability frames)
• E (Hold)                : Pray at God Altars
• 1, 2, 3, 4              : Cast Divine Powers (Zeus, Poseidon, Hades, Ares)
• G                       : [ARMY COMMAND] Order Greek Phalanx to Charge & Attack!
• H                       : [ARMY COMMAND] Order Greek Phalanx to Regroup on Player!
• Tab                     : Divine Codex
• Esc                     : Pause Menu

Extract all files from this ZIP archive and run PantheonsWrath.exe!
===================================================================
