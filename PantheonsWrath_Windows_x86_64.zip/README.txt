===================================================================
🏛️ PANTHEON'S WRATH: CHAMPIONS OF HELLAS 🏛️
===================================================================

A 3D Greek Action Combat Game
Built with Godot 4.7.2 Engine & Blender 4.2 LTS Animations

-------------------------------------------------------------------
🎮 CONTROLS:
-------------------------------------------------------------------
  W, A, S, D       : Move Warrior
  Mouse Look       : Orbit Camera (pitch and yaw)
  Left Click / J   : Melee Sword Attack (2-Hit Combo)
  Spacebar / K     : Dodge Roll (with invulnerability frames)
  Hold E           : Pray at Divine Altars (Unlocks God Powers)
  1 / Q            : Zeus - Wrath of Olympus (Lightning Strike)
  2 / F            : Poseidon - Tidal Cataclysm (Tidal Wave)
  3 / R            : Hades - Soul Leech (Life Steal / Heal)
  4 / C            : Ares - Bloodlust of War (+120% Melee Fury)
  Escape           : Toggle Mouse Capture / Pause

-------------------------------------------------------------------
⚡ HOW TO PLAY:
-------------------------------------------------------------------
1. Run PantheonsWrath.exe.
2. Defend the sacred sanctuary from 3 waves of Tartarus demons.
3. Visit the 4 Altars (Zeus at North, Poseidon at West, Hades at South,
   Ares at East) and hold [E] to receive their blessings.
4. Unleash god powers with number keys [1, 2, 3, 4] to defeat the horde
   and face the Pit Warlord in Wave 3!
